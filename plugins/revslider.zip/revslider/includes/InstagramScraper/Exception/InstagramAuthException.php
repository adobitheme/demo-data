<?php

namespace InstagramScraper\Exception;


class InstagramAuthException extends \Exception
{

}