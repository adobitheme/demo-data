<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Services_El extends Widget_Base {

	public function get_name() {
		return 'art-services';
	}

	public function get_title() {
		return esc_html__( 'Art: Services', 'pachin-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'pachin-addons' )
			]
		);

        $this->add_control(
            'number',
            [
                'label'       => esc_html__( 'Number', 'pachin-addons' ),
                'type'        => Controls_Manager::NUMBER,
                'label_block' => true
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'pachin-addons' )
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'pachin-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'pachin-addons' ),
                ],
                'default' => 'default',
            ]
        );

        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        //Class SC
        $cls_sc = ' layout-' . $layout;

        ?>
        <div class="art-addon-services art-addon <?php echo $cls_sc;?>">
            <?php art_get_element_template( $this->get_base(), array( 'shortcode' => $settings ), $layout );?>
        </div>
		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Services_El()
);