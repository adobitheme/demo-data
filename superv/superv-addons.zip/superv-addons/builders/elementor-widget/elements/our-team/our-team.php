<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Our_team_El extends Widget_Base {

	public function get_name() {
		return 'art-our-team';
	}

	public function get_title() {
		return esc_html__( 'Art: Our Team', 'superv-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'superv-addons' )
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label'       => esc_html__( 'Name', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'works',
            [
                'label'       => esc_html__( 'Works', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label'         => esc_html__( 'Upload Image', 'superv-addons' ),
                'type'        => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'link_fb',
            [
                'label'       => esc_html__( 'Link Facebook', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'link_tw',
            [
                'label'       => esc_html__( 'Link Twitter', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'link_g',
            [
                'label'       => esc_html__( 'Link Google+', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'link_in',
            [
                'label'       => esc_html__( 'Link Instagram', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $this->add_control(
            'item_team',
            [
                'label'       => esc_html__( 'Team', 'superv-addons' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
                'separator'   => 'before'
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'superv-addons' )
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );

        $this->add_control(
            'style',
            [
                'label'   => __( 'Style', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style-1' => esc_html__( 'Style 1', 'superv-addons' ),
                ],
                'default' => 'style-1',
            ]
        );

        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$teams = array();
		foreach ($settings['item_team'] as $key => $value) {
            $teams[$key] = array(
                'name' => $value['name'],
                'works' => $value['works'],
                'image' => $value['image']['id'],
            );
        }
        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        $style = ( !empty( $settings['style'] ) ) ? $settings['style'] : 'style-1';
        //Class SC
        $cls_sc = ' layout-' . $layout;
        $cls_sc .= ' ' . $style;

        ?>
        <div class="art-addon-our-team art-addon <?php echo $cls_sc;?>">
            <?php art_get_element_template( $this->get_base(), array( 'shortcode' => $settings, 'teams' => $teams ), $layout );?>
        </div>
		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Our_team_El()
);