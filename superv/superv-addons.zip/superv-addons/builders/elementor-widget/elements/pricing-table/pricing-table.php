<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Pricing_Table_El extends Widget_Base {

	public function get_name() {
		return 'art-pricing-table';
	}

	public function get_title() {
		return esc_html__( 'Art: Pricing Table', 'superv-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'superv-addons' )
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label'       => esc_html__( 'Name', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'original_price',
            [
                'label'       => __( 'Original Price', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'price',
            [
                'label'       => esc_html__( 'Price', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'content_pricing',
            [
                'label'       => esc_html__( 'Content', 'course-builder' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => ''
            ]
        );

        $repeater->add_control(
            'image_pricing',
            [
                'label'     => esc_html__( 'Choose Image', 'superv-addons' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'title_url',
            [
                'label'       => esc_html__( 'Title URL', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'url',
            [
                'label'       => esc_html__( 'URL', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'item_featured',
            [
                'label'        => __( 'Featured?', 'eduma' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'false',
            ]
        );

        $this->add_control(
            'list_table',
            [
                'label'       => esc_html__( 'Pricing table', 'superv-addons' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ name }}}',
                'separator'   => 'before'
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'superv-addons' )
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );

        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$i=0;
        foreach ($settings['list_table'] as $list_table):
            $settings['list_table'][$i]['item_link'] = array(
                'title' => $list_table['title_url'],
                'url' => $list_table['url'],
            );
            $settings['list_table'][$i]['image_pricing'] = $list_table['image_pricing']['id'];
            $i++;
        endforeach;

        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        //Class SC
        $cls_sc = ' layout-' . $layout;

        ?>
        <div class="art-addon-pricing-table art-addon <?php echo $cls_sc;?>">
            <?php art_get_element_template( $this->get_base(), array( 'shortcode' => $settings, 'list_table' => $settings['list_table'] ), $layout );?>
        </div>
		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Pricing_Table_El()
);