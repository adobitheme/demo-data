<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Video_El extends Widget_Base {

	public function get_name() {
		return 'art-video';
	}

	public function get_title() {
		return esc_html__( 'Art: Video', 'superv-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'superv-addons' )
			]
		);

        $this->add_control(
            'background_image',
            [
                'label'     => esc_html__( 'Choose Image', 'superv-addons' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'video_url',
            [
                'label'       => esc_html__( 'Video URL', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'superv-addons' )
            ]
        );
        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                    'icon' => esc_html__( 'Icon', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );
        $this->add_control(
            'style',
            [
                'label'   => __( 'Style', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );
        $this->add_responsive_control(
            'height',
            [
                'label' => __( 'Height (px)', 'superv-addons' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 500,
                ],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                ],
            ]
        );

        $this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
        $settings['background_image'] = $settings['background_image']['id'];
        $link = array(
            'url' => $settings['video_url'],
        );

        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        $style = ( !empty( $settings['style'] ) ) ? 'style-' . $settings['style'] : 'style-default';
        //Class SC
        $cls_sc = ' layout-' . $layout;
        $cls_sc .= ' ' . $style;
        $cls_sc .= !empty( $settings['text_align'] ) ? ' text-' . $settings['text_align'] : '';
        ?>
        <div class="art-addon-video art-addon <?php echo $cls_sc;?>">
            <?php
            art_get_element_template(
                $this->get_base(),
                array(
                    'shortcode' => $settings,
                    'link' => $link
                ),
                $layout
            );
            ?>
        </div>
		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Video_El()
);