<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Menu_El extends Widget_Base {

	public function get_name() {
		return 'art-menu';
	}

	public function get_title() {
		return esc_html__( 'Art: Menu', 'superv-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'superv-addons' )
			]
		);

        $this->add_control(
            'menu_categories',
            [
                'label'   => esc_html__( 'Select Categories', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT2,
                'options' => $this->art_get_menu_categories(),
                'multiple' => true,
            ]
        );

        $this->add_control(
            'number',
            [
                'label'       => esc_html__( 'Number', 'superv-addons' ),
                'type'        => Controls_Manager::NUMBER,
                'label_block' => true
            ]
        );

        $this->add_control(
            'columns',
            [
                'label'       => esc_html__( 'Columns', 'superv-addons' ),
                'type'        => Controls_Manager::NUMBER,
                'default'     => 1,
                'label_block' => true
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'superv-addons' )
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );

        $this->add_control(
            'style',
            [
                'label'   => __( 'Style', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style-1' => esc_html__( 'Style 1', 'superv-addons' ),
                    'style-2' => esc_html__( 'Style 2', 'superv-addons' ),
                ],
                'default' => 'style-1',
            ]
        );

        $this->add_control(
            'color',
            [
                'label'   => __( 'Color', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'normal' => esc_html__( 'Normal', 'superv-addons' ),
                    'dark' => esc_html__( 'Dark', 'superv-addons' ),
                ],
                'default' => 'normal',
            ]
        );

        // Custom Description Setting
        $this->add_control(
            'show_filter',
            [
                'label'        => __( 'Show Filter?', 'superv-addons' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();

        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        $style = ( !empty( $settings['style'] ) ) ? $settings['style'] : 'style-1';
        $color = ( !empty( $settings['color'] ) ) ? $settings['color'] : 'normal';
        //Class SC
        $cls_sc = ' layout-' . $layout;
        $cls_sc .= ' ' . $style;
        $cls_sc .= ' color-' . $color;

        $terms = get_terms( 'menu-cat', array(
            'hide_empty' => false,
            'number' => 4,
            'include' => $settings['menu_categories']
        ) );

        ?>
        <div class="art-addon-menu art-addon <?php echo $cls_sc;?>">
            <?php
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
                art_get_element_template(
                    $this->get_base(),
                    array(
                        'shortcode' => $settings,
                        'terms' => $terms,
                    ),
                    $layout
                );
            }
            ?>
        </div>
		<?php
	}

    function art_get_menu_categories() {
        $menu_categories = get_terms( 'menu-cat', array(
            'hide_empty' => 0,
            'parent'     => 0
        ) );
        $cate               = array();
        $cate[]             = esc_html__( 'All', 'superv-addons' );
        if ( is_array( $menu_categories ) ) {
            foreach ( $menu_categories as $cat ) {
                $cate[ $cat->term_id ] = $cat->name;
            }
        }

        return $cate;
    }

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Menu_El()
);