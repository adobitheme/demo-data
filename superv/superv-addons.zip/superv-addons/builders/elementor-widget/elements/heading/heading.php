<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Heading_El extends Widget_Base {

	public function get_name() {
		return 'art-heading';
	}

	public function get_title() {
		return esc_html__( 'Art: Heading', 'superv-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'superv-addons' )
			]
		);

		$this->add_control(
			'sub_title',
			[
				'label'       => __( 'Sub Title', 'superv-addons' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true
			]
		);

        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $this->add_control(
            'description',
            [
                'label'       => __( 'Description', 'superv-addons' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'superv-addons' )
            ]
        );
        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );
        $this->add_control(
            'style',
            [
                'label'   => __( 'Style', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                    'white' => esc_html__( 'White', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );
        $this->add_responsive_control(
            'max_width',
            [
                'label' => __( 'Max width (px)', 'superv-addons' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                ],
            ]
        );
        $this->add_responsive_control(
            'text_align',
            [
                'label' => __( 'Alignment', 'superv-addons' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'superv-addons' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'superv-addons' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'superv-addons' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'superv-addons' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        // Custom Sub Title Setting
        $this->add_control(
            'custom_sub_title_setting',
            [
                'label'        => __( 'Custom Sub Title Setting?', 'superv-addons' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'custom_sub_title',
                'default'      => '',
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'sub_title_font_size',
            [
                'label' => __( 'Sub Title Font Size (px)', 'superv-addons' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'range' => [
                    'px' => [
                        'min' => 14,
                        'max' => 40,
                    ],
                ],
                'condition' => [
                    'custom_sub_title_setting' => [ 'custom_sub_title' ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .sub_title' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
        $this->add_control(
            'sub_title_color',
            [
                'label' => __( 'Sub Title Color', 'superv-addons' ),
                'type'  => Controls_Manager::COLOR,
                'default' => '#000000',
                'condition' => [
                    'custom_sub_title_setting' => [ 'custom_sub_title' ]
                ]
            ]
        );

        // Custom Title Setting
        $this->add_control(
            'custom_title_setting',
            [
                'label'        => __( 'Custom Title Setting?', 'superv-addons' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'custom_title',
                'default'      => '',
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'title_font_size',
            [
                'label' => __( 'Title Font Size (px)', 'superv-addons' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 32,
                ],
                'range' => [
                    'px' => [
                        'min' => 24,
                        'max' => 90,
                    ],
                ],
                'condition' => [
                    'custom_title_setting' => [ 'custom_title' ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'title_font_weight',
            [
                'label'   => __( 'Font Weight', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '100' => esc_html__( '100', 'superv-addons' ),
                    '200' => esc_html__( '200', 'superv-addons' ),
                    '300' => esc_html__( '300', 'superv-addons' ),
                    '400' => esc_html__( '400', 'superv-addons' ),
                    '500' => esc_html__( '500', 'superv-addons' ),
                    '600' => esc_html__( '600', 'superv-addons' ),
                    '700' => esc_html__( '700', 'superv-addons' ),
                    '800' => esc_html__( '800', 'superv-addons' ),
                    '900' => esc_html__( '900', 'superv-addons' ),
                ],
                'default' => '700',
            ]
        );
        $this->add_responsive_control(
            'line_height',
            [
                'label'       => __( 'Line Height', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'line-height: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label' => __( 'Title Color', 'superv-addons' ),
                'type'  => Controls_Manager::COLOR,
                'default' => '#000000',
                'condition' => [
                    'custom_title_setting' => [ 'custom_title' ]
                ]
            ]
        );

        // Custom Description Setting
        $this->add_control(
            'custom_description_setting',
            [
                'label'        => __( 'Custom Description Setting?', 'superv-addons' ),
                'type'         => Controls_Manager::SWITCHER,
                'return_value' => 'custom_description',
                'default'      => '',
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control(
            'description_font_size',
            [
                'label' => __( 'Description Font Size (px)', 'superv-addons' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 32,
                ],
                'range' => [
                    'px' => [
                        'min' => 24,
                        'max' => 60,
                    ],
                ],
                'condition' => [
                    'custom_description_setting' => [ 'custom_description' ]
                ]
            ]
        );
        $this->add_control(
            'description_color',
            [
                'label' => __( 'Description Color', 'superv-addons' ),
                'type'  => Controls_Manager::COLOR,
                'default' => '#000000',
                'condition' => [
                    'custom_description_setting' => [ 'custom_description' ]
                ]
            ]
        );

        $this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        $style = ( !empty( $settings['style'] ) ) ? 'style-' . $settings['style'] : 'style-default';
        //Class SC
        $cls_sc = ' layout-' . $layout;
        $cls_sc .= ' ' . $style;
        // Style wrap
        $style_wrap = ( !empty( $settings['max_width']['size'] ) ) ? ' max-width: ' . $settings['max_width']['size'] . 'px;' : '';
        $style_wrap = $style_wrap ? ' style="' . $style_wrap . '"' : '';
        // Custom style
        $style_title = $style_sub_title = $style_description = '';
        if( !empty( $settings['custom_sub_title_setting'] ) ) {
            $style_sub_title .= ( !empty($settings['sub_title_color']) ) ? 'color: ' . $settings['sub_title_color'] . ';' : '';
            $style_sub_title = ' style="' . $style_sub_title . '"';
        }
        if( !empty( $settings['custom_title_setting'] ) ) {
            $style_title .= 'font-weight: ' . $settings['title_font_weight'] . ';';
            $style_title .= ( !empty($settings['title_color']) ) ? 'color: ' . $settings['title_color'] . ';' : '';
            $style_title = ' style="' . $style_title . '"';
        }
        if( !empty( $settings['custom_description_setting'] ) ) {
            $style_description .= 'font-size: ' . $settings['description_font_size']['size'] . 'px;';
            $style_description .= ( !empty($settings['description_color']) ) ? 'color: ' . $settings['description_color'] . ';' : '';
            $style_description = ' style="' . $style_description . '"';
        }
        ?>
        <div class="art-addon-heading art-addon <?php echo $cls_sc;?>">
            <?php
            art_get_element_template(
                $this->get_base(),
                array(
                    'shortcode' => $settings,
                    'style_sub_title' => $style_sub_title,
                    'style_title' => $style_title,
                    'style_wrap' => $style_wrap,
                    'style_description' => $style_description,
                ),
                $layout
            );
            ?>
        </div>
		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Heading_El()
);