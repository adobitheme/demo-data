<?php

namespace Elementor;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Art_Brands_El extends Widget_Base {

	public function get_name() {
		return 'art-accodion';
	}

	public function get_title() {
		return esc_html__( 'Art: Brands', 'superv-addons' );
	}

	public function get_icon() {
		return 'eicon-apps';
	}

	public function get_categories() {
		return [ 'art-elements' ];
	}

	public function get_base() {
		return basename( __FILE__, '.php' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'content_tab',
			[
				'label' => __( 'Content', 'superv-addons' )
			]
		);

        $repeater = new Repeater();

        $this->add_control(
            'list_images',
            [
                'label'       => esc_html__( 'List Images', 'superv-addons' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
                'separator'   => 'before'
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label'         => esc_html__( 'Image', 'superv-addons' ),
                'type'        => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'title_url',
            [
                'label'       => esc_html__( 'Link', 'superv-addons' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'setting_tab',
            [
                'label' => __( 'Setting', 'superv-addons' )
            ]
        );

        $this->add_control(
            'layout',
            [
                'label'   => __( 'Layout', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'default' => esc_html__( 'Default', 'superv-addons' ),
                ],
                'default' => 'default',
            ]
        );

        $this->add_control(
            'style',
            [
                'label'   => __( 'Style', 'superv-addons' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style-1' => esc_html__( 'Style 1', 'superv-addons' ),
                ],
                'default' => 'style-1',
            ]
        );

        $this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
        $i=0;
        foreach ($settings['list_images'] as $item):
            $settings['list_images'][$i]['item_link'] = array(
                'url' => $item['title_url'],
            );
            $settings['list_images'][$i]['custom_image'] = $item['custom_image']['id'];
            $i++;
        endforeach;

        $layout = ( !empty( $settings['layout'] ) ) ? $settings['layout'] : 'default';
        $style = ( !empty( $settings['style'] ) ) ? $settings['style'] : 'style-1';
        //Class SC
        $cls_sc = ' layout-' . $layout;
        $cls_sc .= ' ' . $style;
        ?>
        <div class="art-addon-brands art-addon <?php echo $cls_sc;?>">
            <?php art_get_element_template( $this->get_base(), array( 'shortcode' => $settings, 'brands' => $settings['list_images'] ), $layout );?>
        </div>
		<?php
	}

}

Plugin::instance()->widgets_manager->register_widget_type(
    new Art_Brands_El()
);