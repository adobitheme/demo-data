<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit();
}

class Art_Elementor_Extend_Icons {
    private static $instance = null;

    public function __construct() {
        add_action( 'elementor/editor/before_enqueue_styles', array( $this, 'art_font_setup' ) );
    }

    public function art_font_setup() {
        wp_enqueue_style('font-articon', plugins_url('../../../assets/libs/font-articon/art-icon.css', __FILE__));
    }

    public static function get_font_articon() {
        $articon = array(
            'articon-worker' => 'worker',
            'articon-trophy' => 'trophy',
            'articon-solution' => 'solution',
            'articon-sketch' => 'sketch',
            'articon-share' => 'share',
            'articon-robotic-arm' => 'robotic-arm',
            'articon-robot-arm' => 'robot-arm',
            'articon-project-management' => 'project-management',
            'articon-medal' => 'medal',
            'articon-laboratory' => 'laboratory',
            'articon-hook' => 'hook',
            'articon-help' => 'help',
            'articon-gas-station' => 'gas-station',
            'articon-factory' => 'factory',
            'articon-creative-idea' => 'creative-idea',
        );

        return $articon;
    }

    public static function get_instance() {
        if ( self::$instance == null ) {
            self::$instance = new self;
        }

        return self::$instance;
    }
}

Art_Elementor_Extend_Icons::get_instance();