<?php

namespace Elementor;

function art_elementor_init() {
    // Creating a new category
    Plugin::instance()->elements_manager->add_category(
        'art-elements',
        [
            'title' => esc_html__( 'Art Elements', 'superv-addons' ),
            'icon'  => 'font'
        ]
    );

}

add_action( 'elementor/init', 'Elementor\art_elementor_init' );
