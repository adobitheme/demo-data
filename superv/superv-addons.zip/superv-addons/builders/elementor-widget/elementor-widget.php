<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ART_EL_PATH', ART_ADDONS_PATH . 'builders/elementor-widget/' );
define( 'ART_EL_ADDONS_PATH', ART_EL_PATH . 'elements/' );

require_once ART_EL_PATH . 'inc/helper.php';
require_once ART_EL_PATH . 'inc/extend_icons.php';

function art_add_new_elements() {

    //Load elements
    require ART_EL_ADDONS_PATH . 'accordion/accordion.php';
    require ART_EL_ADDONS_PATH . 'brands/brands.php';
    require ART_EL_ADDONS_PATH . 'button/button.php';
    require ART_EL_ADDONS_PATH . 'counter/counter.php';
    require ART_EL_ADDONS_PATH . 'features/features.php';
    require ART_EL_ADDONS_PATH . 'galleries/galleries.php';
    require ART_EL_ADDONS_PATH . 'heading/heading.php';
    require ART_EL_ADDONS_PATH . 'icon-box/icon-box.php';
    require ART_EL_ADDONS_PATH . 'image-box/image-box.php';
    require ART_EL_ADDONS_PATH . 'menu/menu.php';
    require ART_EL_ADDONS_PATH . 'menu-categories/menu-categories.php';
    require ART_EL_ADDONS_PATH . 'our-team/our-team.php';
    require ART_EL_ADDONS_PATH . 'posts/posts.php';
    require ART_EL_ADDONS_PATH . 'pricing-table/pricing-table.php';
    require ART_EL_ADDONS_PATH . 'services/services.php';
    require ART_EL_ADDONS_PATH . 'tabs/tabs.php';
    require ART_EL_ADDONS_PATH . 'testimonials/testimonials.php';
    require ART_EL_ADDONS_PATH . 'video/video.php';

}

add_action( 'elementor/widgets/widgets_registered', 'art_add_new_elements' );