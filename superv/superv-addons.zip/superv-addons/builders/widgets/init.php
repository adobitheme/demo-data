<?php
/*
Plugin Name: Superv Widgets
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Register widgets
add_action( 'widgets_init', 'art_register_widget' );
function art_register_widget() {
    include_once( __DIR__ . '/button/button.php' );
    include_once( __DIR__ . '/icon-box/icon-box.php' );
    include_once( __DIR__ . '/posts/posts.php' );
    include_once( __DIR__ . '/search/search.php' );
    include_once( __DIR__ . '/socials-link/socials-link.php' );
}

// Register Script for widget
add_action( 'wp_enqueue_scripts', 'loadStyleWidgets', 99999 );
function loadStyleWidgets() {
    // Load CSS
    wp_register_style( 'art-widget-button-css', plugins_url('button/assets/css/button.css', __FILE__) );
    wp_register_style( 'art-widget-icon-box-css', plugins_url('icon-box/assets/css/icon-box.css', __FILE__) );
    wp_register_style( 'art-widget-posts-css', plugins_url('posts/assets/css/posts.css', __FILE__) );
    wp_register_style( 'art-widget-search-css', plugins_url('search/assets/css/search.css', __FILE__) );
    wp_register_style( 'art-widget-socials-link-css', plugins_url('socials-link/assets/css/socials-link.css', __FILE__) );

    // Load JS
    wp_register_script( 'art-widget-search-script', plugins_url('search/assets/js/search.js', __FILE__) );
}