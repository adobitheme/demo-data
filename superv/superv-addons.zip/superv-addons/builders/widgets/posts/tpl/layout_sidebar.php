<div class="post-list">
    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
    <div class="post-item">
        <div class="post-image">
            <a href="<?php the_permalink();?>">
                <?php echo art_feature_image( get_post_thumbnail_id(), 'full', 80, 80 );?>
            </a>
        </div>

        <div class="post-text">
            <h4 class="title">
                <a href="<?php the_permalink();?>">
                    <?php the_title();?>
                </a>
            </h4>

            <div class="info">
                <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo get_the_date();?>
            </div>
        </div>
    </div>
    <?php endwhile;?>
</div>