<?php
register_widget( 'Art_Posts' );
class Art_Posts extends WP_Widget {
    /**
     * @var string
     *
     * @since 1.0
     */
    protected $defaults;
    public $widget_options;

    /**
     * superv_Posts constructor.
     *
     * @since 1.0
     */
    function __construct() {
        $this->defaults = array(
            'title'     => '',
            'layout'     => '',
            'limit'     => '',
            'ext_class'     => '',
        );
        parent::__construct( false, __( 'Art Posts', 'superv-addons' ) );
    }

    /**
     * Print content.
     *
     * @since 0.8.2
     *
     * @param array $args
     * @param array $instance
     */
    function widget( $args, $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        extract( $instance );
        extract( $args );
        wp_enqueue_style('art-widget-posts-css');
        $title = ( !empty( $instance['title'] ) ) ? $instance['title'] : '';
        $layout = ( !empty( $instance['layout'] ) ) ? $instance['layout'] : 'layout_footer';
        $limit = ( !empty( $instance['limit'] ) ) ? $instance['limit'] : '';
        $class = ( !empty( $instance['class'] ) ) ? $instance['class'] : '';
        $query = array(
            'posts_per_page'      => $limit,
            'no_found_rows'       => true,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => true
        );
        $query = new WP_Query( $query );
        if ( $query->have_posts() ) {
            echo '<div class="widget widget_art_posts ' . $layout . ' ' . $class . '">';
            if ( $title ) {
                echo $args['before_title'] . $title . $args['after_title'];
            }
            include_once(__DIR__ . '/tpl/' . $layout . '.php');
            echo '</div>';
            wp_reset_postdata();
        }
    }

    /**
     * Update settings widget.
     *
     * @since 0.8.2
     *
     * @param array $new_instance
     * @param array $old_instance
     *
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        $instance               = $old_instance;
        $instance['title']      = strip_tags( $new_instance['title'] );
        $instance['layout']      = $new_instance['layout'];
        $instance['limit']      = strip_tags( $new_instance['limit'] );
        $instance['ext_class']      = strip_tags( $new_instance['ext_class'] );
        return $instance;
    }

    /**
     * Form widget.
     *
     * @since 0.8.2
     *
     * @param array $instance
     *
     * @return mixed
     */
    function form( $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"><?php esc_html_e( 'Layout:', 'superv-addons' ); ?></label>
            <select id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
                <option value="layout_sidebar"<?php echo ($instance['layout'] == 'layout_sidebar') ? ' selected' : '';?>><?php esc_html_e( 'Sidebar', 'superv-addons' ); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php esc_html_e( 'Limit:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['limit'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'ext_class' ) ); ?>"><?php esc_html_e( 'Extra Class:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'ext_class' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'ext_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['ext_class'] ); ?>">
        </p>
        <?php
        return;
    }
}