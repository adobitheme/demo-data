(function ($) {
    'use strict'

    /**
     * Addon Search
     */
    var pachin_search = function() {
        try {
            $('.widget_pachin_search.layout_default i').on( 'click', function () {
                $(this).parent().find('.search_form').toggleClass('active');
            } );
        } catch(er) {console.log(er);}
    };

    // Dom Ready
    $(function() {
        $( window ).load(function() {
            pachin_search();
        });
    });
})(jQuery);