<i class="fa fa-search" aria-hidden="true"></i>
<form class="search_form" action="<?php echo esc_url(home_url( '/' ));?>">
    <input type="text" name="s" class="key" placeholder="Search">
</form>