<?php
$link = !empty($instance['link']) ? $instance['link'] : '';
?>
<div class="wrap-widget">
    <a href="<?php esc_url($link);?>" class="art_button">
        <?php echo esc_html($instance['title']);?>
    </a>
</div>