<?php
register_widget( 'Art_Button' );
class Art_Button extends WP_Widget {
    /**
     * @var string
     *
     * @since 1.0
     */
    protected $defaults;
    public $widget_options;

    /**
     * Art_Button constructor.
     *
     * @since 1.0
     */
    function __construct() {
        $this->defaults = array(
            'title'     => '',
            'style'     => '',
            'link'     => '',
            'ext_class'     => '',
        );
        parent::__construct( false, __( 'Art Button', 'superv-addons' ) );
    }

    /**
     * Print content.
     *
     * @since 0.8.2
     *
     * @param array $args
     * @param array $instance
     */
    function widget( $args, $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        extract( $args );
        wp_enqueue_style('art-widget-button-css');
        $style = ( !empty( $instance['style'] ) ) ? $instance['style'] : 'style-default';
        $class = ( !empty( $instance['class'] ) ) ? $instance['class'] : '';
        $class .= ( !empty( $instance['style'] ) ) ? ' style-' . $instance['style'] : '';
        echo '<div class="widget widget_art_button '. $class .'">';
        include_once( __DIR__ . '/tpl/default.php' );
        echo '</div>';
    }

    /**
     * Update settings widget.
     *
     * @since 0.8.2
     *
     * @param array $new_instance
     * @param array $old_instance
     *
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        $instance               = $old_instance;
        $instance['title']      = strip_tags( $new_instance['title'] );
        $instance['style']      = $new_instance['style'];
        $instance['link']      = strip_tags( $new_instance['link'] );
        $instance['ext_class']      = strip_tags( $new_instance['ext_class'] );
        return $instance;
    }

    /**
     * Form widget.
     *
     * @since 0.8.2
     *
     * @param array $instance
     *
     * @return mixed
     */
    function form( $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Style:', 'superv-addons' ); ?></label>
            <select id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>">
                <option value="default"<?php echo ($instance['style'] == 'default') ? ' selected' : '';?>><?php esc_html_e( 'Default', 'bilo-addons' ); ?></option>
                <option value="border"<?php echo ($instance['style'] == 'border') ? ' selected' : '';?>><?php esc_html_e( 'Border', 'bilo-addons' ); ?></option>
                <option value="round"<?php echo ($instance['style'] == 'round') ? ' selected' : '';?>><?php esc_html_e( 'Round', 'bilo-addons' ); ?></option>
                <option value="white_round"<?php echo ($instance['style'] == 'white_round') ? ' selected' : '';?>><?php esc_html_e( 'Round White', 'bilo-addons' ); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>"><?php esc_html_e( 'Link:', 'bilo-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['link'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'ext_class' ) ); ?>"><?php esc_html_e( 'Extra Class:', 'bilo-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'ext_class' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'ext_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['ext_class'] ); ?>">
        </p>
        <?php
        return;
    }
}