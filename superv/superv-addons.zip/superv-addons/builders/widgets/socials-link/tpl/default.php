<?php
$title = !empty($instance['title']) ? $instance['title'] : '';
$link_fb = !empty($instance['link_fb']) ? $instance['link_fb'] : '';
$link_tw = !empty($instance['link_tw']) ? $instance['link_tw'] : '';
$link_in = !empty($instance['link_in']) ? $instance['link_in'] : '';
$link_ins = !empty($instance['link_ins']) ? $instance['link_ins'] : '';
if ( $title ) {
    echo $args['before_title'] . $title . $args['after_title'];
}
?>
<div class="wrap-shortcode">
    <?php if($link_fb) {?>
        <a href="<?php echo $link_fb;?>" target="_blank" class="social-item">
            <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-fb.png" alt="">
        </a>
    <?php }?>

    <?php if($link_tw) {?>
        <a href="<?php echo $link_tw;?>" target="_blank" class="social-item">
            <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-tw.png" alt="">
        </a>
    <?php }?>

    <?php if($link_in) {?>
        <a href="<?php echo $link_in;?>" target="_blank" class="social-item">
            <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-in.png" alt="">
        </a>
    <?php }?>

    <?php if($link_ins) {?>
        <a href="<?php echo $link_ins;?>" target="_blank" class="social-item">
            <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-pin.png" alt="">
        </a>
    <?php }?>
</div>