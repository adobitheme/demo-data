<div class="wrap-widget">
    <?php if( $icon ) :?>
    <div class="icon">
        <i class="<?php echo $icon;?>"></i>
    </div>
    <?php endif;?>
    <div class="content">
        <?php if( $title ) :?>
        <h3><?php echo $title;?></h3>
        <?php endif;?>
        <span><?php echo $description;?></span>
    </div>
</div>