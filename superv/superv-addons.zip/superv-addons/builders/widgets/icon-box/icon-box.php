<?php
register_widget( 'Art_Icon_Box' );
class Art_Icon_Box extends WP_Widget {
    /**
     * @var string
     *
     * @since 1.0
     */
    protected $defaults;
    public $widget_options;

    /**
     * superv_Posts constructor.
     *
     * @since 1.0
     */
    function __construct() {
        $this->defaults = array(
            'title'     => '',
            'style'     => '',
            'ext_class'     => '',
        );
        parent::__construct( false, __( 'Art Icon box', 'superv-addons' ) );
    }

    /**
     * Print content.
     *
     * @since 0.8.2
     *
     * @param array $args
     * @param array $instance
     */
    function widget( $args, $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        extract( $instance );
        extract( $args );
        wp_enqueue_style('art-widget-icon-box-css');
        $title = ( !empty( $instance['title'] ) ) ? $instance['title'] : '';
        $style = ( !empty( $instance['style'] ) ) ? $instance['style'] : 'style-1';
        $icon = ( !empty( $instance['icon_class'] ) ) ? $instance['icon_class'] : '';
        $description = ( !empty( $instance['description'] ) ) ? $instance['description'] : '';
        $class = ( !empty( $instance['class'] ) ) ? $instance['class'] : '';

        echo '<div class="widget widget_art_icon_box ' . $style . ' ' . $class . '">';
        include_once(__DIR__ . '/tpl/default.php');
        echo '</div>';
    }

    /**
     * Update settings widget.
     *
     * @since 0.8.2
     *
     * @param array $new_instance
     * @param array $old_instance
     *
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        $instance               = $old_instance;
        $instance['title']      = strip_tags( $new_instance['title'] );
        $instance['icon_class']      = strip_tags( $new_instance['icon_class'] );
        $instance['description']      = strip_tags( $new_instance['description'] );
        $instance['style']      = $new_instance['style'];
        $instance['ext_class']      = strip_tags( $new_instance['ext_class'] );
        return $instance;
    }

    /**
     * Form widget.
     *
     * @since 0.8.2
     *
     * @param array $instance
     *
     * @return mixed
     */
    function form( $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"><?php esc_html_e( 'Style:', 'superv-addons' ); ?></label>
            <select id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>">
                <option value="style-1"<?php echo ($instance['style'] == 'style-1') ? ' selected' : '';?>><?php esc_html_e( 'Style 1', 'superv-addons' ); ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'icon_class' ) ); ?>"><?php esc_html_e( 'Icon:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_class' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['icon_class'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"><?php esc_html_e( 'Description:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['description'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'ext_class' ) ); ?>"><?php esc_html_e( 'Extra Class:', 'superv-addons' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'ext_class' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'ext_class' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['ext_class'] ); ?>">
        </p>
        <?php
        return;
    }
}