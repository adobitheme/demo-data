<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Map shortcodes to Visual Composer
require_once(__DIR__ . '/vc-map.php');

/**
 * Include shortcodes files for Visual Composer
 */
// shortcode accodion
//require_once(__DIR__ . '/shortcodes/accodion/accodion.php');