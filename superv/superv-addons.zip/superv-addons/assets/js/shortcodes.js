;(function($) {

    'use strict'
    var counter_box = {
        init: function () {
            var waypoint = void 0 !== $.fn.waypoint;

            counter_box.counter();

            var counter = $('.number_counter');

            counter.waypoint(function () {
                var $this = $(this);
                if (!$this.hasClass('animated')) {
                    var number = $this.data('number');
                    $this.countTo({
                        from: 0,
                        to: number,
                        refreshInterval: 40,
                        speed: 1000,
                        formatter: function (value, options) {
                            value = value.toFixed();
                            return value;
                        }
                    });

                    $this.addClass('animated');
                }
            }, {
                offset: $(window).height()
            });
        },

        counter: function () {
            var a = $;
            a.fn.countTo = function (g) {
                g = g || {};
                return a(this).each(function () {
                    function e(a) {
                        a = b.formatter.call(h, a, b);
                        f.html(a);
                    }

                    var b = a.extend({}, a.fn.countTo.defaults, {
                            from: a(this).data("from"),
                            to: a(this).data("to"),
                            speed: a(this).data("speed"),
                            refreshInterval: a(this).data("refresh-interval"),
                            decimals: a(this).data("decimals")
                        }, g), j = Math.ceil(b.speed / b.refreshInterval), l = (b.to - b.from) / j, h = this, f = a(this),
                        k = 0, c = b.from, d = f.data("countTo") || {};
                    f.data("countTo", d);
                    d.interval && clearInterval(d.interval);
                    d.interval =
                        setInterval(function () {
                            c += l;
                            k++;
                            e(c);
                            "function" === typeof b.onUpdate && b.onUpdate.call(h, c);
                            k >= j && (f.removeData("countTo"), clearInterval(d.interval), c = b.to, "function" === typeof b.onComplete && b.onComplete.call(h, c));
                        }, b.refreshInterval);
                    e(c);
                });
            };
            a.fn.countTo.defaults = {
                from: 0, to: 0, speed: 1E3, refreshInterval: 100, decimals: 0, formatter: function (a, e) {
                    a = a.toFixed(e.decimals);
                    return a;
                }, onUpdate: null, onComplete: null
            };
        },
    }

    // spacing
    var spacer = function() {
        $(window).on('load resize', function() {
            var mode = 'desktop';

            if ( matchMedia( 'only screen and (max-width: 991px)' ).matches )
                mode = 'mobile';

            if ( matchMedia( 'only screen and (max-width: 767px)' ).matches )
                mode = 'smobile';

            $('.at-spacer').each(function(){
                if ( mode == 'desktop' ) {
                    $(this).attr('style', 'height:' + $(this).data('desktop') + 'px')
                } else if ( mode == 'mobile' ) {
                    $(this).attr('style', 'height:' + $(this).data('mobi') + 'px')
                } else {
                    $(this).attr('style', 'height:' + $(this).data('smobi') + 'px')
                }
            })

        });
    };

    /**
     * Row, Column Responsive
     */
    var element_responsive = function() {
        $(window).on('load resize', function() {
            var mode = 'desktop';

            if ( matchMedia( 'only screen and (max-width: 1024px) and (min-width: 768px)' ).matches )
                mode = 'tablet';
            else if ( matchMedia( 'only screen and (max-width: 767px)' ).matches )
                mode = 'mobile';

            $('.vc_row, .vc_row-inner, .wpb_column, .vc_column-inner, .art-addon').each(function(){
                if ( mode == 'tablet' ) {
                    if($(this).data('tablet-class')) {
                        $(this).addClass($(this).data('tablet-class'));
                    }
                }
                if ( mode == 'mobile' ) {
                    if($(this).data('mobile-class')) {
                        $(this).addClass($(this).data('mobile-class'));
                    }
                }
            });
        });
    };

    /**
     * Slick Slide
     */
    var slick_slider = function () {
        var rightToLeft = false;
        var verticalSlide = false;
        var verticalSwipe = false;
        var customdot = false;
        var numOfSlide = 4;
        var numOfScroll = 4;
        var loopSlide = false;
        var autoScroll = false;
        var speedAuto = 5000;
        var centerMode = false;
        var respon = [[4, 4], [3, 3], [2, 2], [1, 1], [1, 1]];

        var parameter = {
            responsive: [[1, 1], [1, 1], [1, 1], [1, 1], [1, 1]],
            customdot: false,
            numofshow: 1,
            numofscroll: 1,
            fade: false,
            loopslide: false,
            autoscroll: false,
            speedauto: 5000,
            verticalslide: false,
            verticalswipe: false,
            rtl: rightToLeft,
            navfor: '',
            animate: false,
            middlearrow: null,
            modecenter: false,
            paddingcenter: '50px',
            speedslide: 50000

        }

        $('.js-call-slick-slide').each(function(){
            var wrapSlick = $(this);
            var slideSlick = $(this).find('.slide-slick');

            // Check show dot, arrows
            var showDot = false;
            if($(wrapSlick).find('.wrap-dot-slick').length > 0) {
                showDot = true;
            }

            var showArrow = false;
            if($(wrapSlick).find('.wrap-arrow-slick').length > 0) {
                showArrow = true;
            }

            // Get data
            numOfSlide = Number($(this).data('numofslide'));
            numOfScroll = Number($(this).data('numofscroll'));
            speedAuto = Number($(this).data('speedauto'));

            if($(this).data('rtl') == '1') {
                rightToLeft = true;
            } else {
                rightToLeft = false;
            }

            if($(this).data('centermode') == '1') {
                centerMode = true;
            } else {
                centerMode = false;
            }

            if($(this).data('loopslide') == '1') {
                loopSlide = true;
            } else {
                loopSlide = false;
            }

            if($(this).data('autoscroll') == '1') {
                autoScroll = true;
            } else {
                autoScroll = false;
            }

            if($(this).data('customdot') == '1') {
                customdot = true;
            } else {
                customdot = false;
            }

            if($(this).data('verticalslide') == '1') {
                verticalSlide = true;
            } else {
                verticalSlide = false;
            }

            if($(this).data('verticalswipe') == '1') {
                verticalSwipe = true;
            } else {
                verticalSwipe = false;
            }

            var str = $(this).data('respon') //'[4, 4], [3, 3], [2, 2], [1, 1], [1, 1]';
            var strArray = str.match(/(\d+)/g);
            respon =    [
                [Number(strArray[0]), Number(strArray[1])],
                [Number(strArray[2]), Number(strArray[3])],
                [Number(strArray[4]), Number(strArray[5])],
                [Number(strArray[6]), Number(strArray[7])],
                [Number(strArray[8]), Number(strArray[9])]
            ]



            // Call slick
            $(slideSlick).slick({
                rtl: rightToLeft,
                vertical: verticalSlide,
                verticalSwiping: verticalSwipe,
                pauseOnFocus: false,
                pauseOnHover: true,
                slidesToShow: numOfSlide,
                slidesToScroll: numOfScroll,
                fade: false,
                centerMode: centerMode,
                infinite: loopSlide,
                autoplay: autoScroll,
                autoplaySpeed: speedAuto,
                arrows: showArrow,
                appendArrows: $(wrapSlick).find('.wrap-arrow-slick'),
                prevArrow: $(wrapSlick).find('.prev-slick'),
                nextArrow: $(wrapSlick).find('.next-slick'),
                dots: showDot,
                appendDots: $(wrapSlick).find('.wrap-dot-slick'),
                dotsClass:'dots-slick',
                customPaging: function(slick, index) {
                    var portrait = $(slick.$slides[index]).data('thumb');

                    if(customdot) return '<img src=" ' + portrait + ' "/>';

                    return '<span></span>'
                },
                responsive: [
                    {
                        breakpoint: 1920,
                        settings: {
                            slidesToShow: respon[0][0],
                            slidesToScroll: respon[0][1]
                        }
                    },
                    {
                        breakpoint: 1400,
                        settings: {
                            slidesToShow: respon[1][0],
                            slidesToScroll: respon[1][1]
                        }
                    },
                    {
                        breakpoint: 991,
                        settings: {
                            slidesToShow: respon[2][0],
                            slidesToScroll: respon[2][1]
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: respon[3][0],
                            slidesToScroll: respon[3][1]
                        }
                    },
                    {
                        breakpoint: 575,
                        settings: {
                            slidesToShow: respon[4][0],
                            slidesToScroll: respon[4][1]
                        }
                    }
                ]
            })
                .on('setPosition', function(event, slick){
                    if($(this).parent().data('equalheight') == '1') {
                        var maxHeight = 0;
                        var $items = $(this).find('.item-slick');

                        $items.each(function(){
                            if($(this).outerHeight() > maxHeight) {
                                maxHeight = $(this).outerHeight();
                            }
                        })

                        $items.css('min-height', maxHeight);
                        //console.log(maxHeight);
                    }

                    // Middle Arrow
                    if($(wrapSlick).data('middlearrow') != null) {
                        var $wrapArrows = $(wrapSlick).find('.wrap-arrow-slick');
                        var middleOf = $(wrapSlick).find($(wrapSlick).data('middlearrow')).outerHeight();

                        $wrapArrows.css('height', middleOf + 'px');
                    }
                });

            // Animate
            if(parameter.animate) {
                $(slideSlick).on('afterChange', function(event, slick, currentSlide){
                    showLayer(currentSlide);
                });
            }

            function showLayer(currentSlide) {
                var layerCurrentItem = $(itemSlick[currentSlide]).find('[data-appear]');

                for(var i=0; i<actionSlick.length; i++) {
                    clearTimeout(actionSlick[i]);
                }

                $(layerSlick).each(function(){
                    $(this).removeClass($(this).data('appear')).css('visibility', 'hidden');
                })


                for(var i=0; i<layerCurrentItem.length; i++) {
                    actionSlick[i] = setTimeout(function(index) {
                        $(layerCurrentItem[index]).addClass($(layerCurrentItem[index]).data('appear')).css('visibility', 'visible');
                    },$(layerCurrentItem[i]).data('delay'),i);
                }
            };


        });

    }

    var magnificpopup_gallery = function () {
        $(document).on('click', '.art-addon-galleries .icon-thumb i', function(e) {
            e.preventDefault();
            var elem = $(this),
                gal_id = elem.parent().data('id'),
                data = {action: 'art_get_images_gallery', gal_id: gal_id};
            elem.attr('class', 'ion-ios-loop-strong fa-spin');
            $.post(ajaxurl, data, function(response) {
                elem.attr('class', 'ion-android-add');
                $('.gallery_show').append(response);
                if ($('.gallery_show img').length > 0) {
                    $('.gallery_show').magnificPopup({
                        mainClass   : 'my-mfp-zoom-in',
                        type        : 'image',
                        delegate    : 'a',
                        showCloseBtn: false,
                        gallery     : {
                            enabled: true,
                        },
                        callbacks   : {
                            open: function() {
                                $.magnificPopup.instance.close = function() {
                                    $('.gallery_show').empty();
                                    $.magnificPopup.proto.close.call(this);
                                };
                            },
                        },
                    }).magnificPopup('open');
                } else {
                    $.magnificPopup.open({
                        mainClass   : 'my-mfp-zoom-in',
                        items       : {
                            src : $('.gallery_show'),
                            type: 'inline',
                        },
                        showCloseBtn: false,
                        callbacks   : {
                            open: function() {
                                $.magnificPopup.instance.close = function() {
                                    $('.thim-gallery-show').empty();
                                    $.magnificPopup.proto.close.call(this);
                                };
                            },
                        },
                    });
                }

            });

        });
    };

    var magnificpopup_image = function() {
        if ($.magnificPopup) {
            $('.magnific_popup').magnificPopup({
                type: 'image',
                zoom: {
                    enabled: true,
                    duration: 300 // don't foget to change the duration also in CSS
                }
            });
        }
    };

    var magnificpopup = function() {
        if ($.magnificPopup) {
            $('.video_popup').magnificPopup({
                disableOn: 700,
                type: 'iframe',
                mainClass: 'mfp-fade',
                removalDelay: 160,
                preloader: false,

                fixedContentPos: false
            });
        }
    };

    var process_fnc = function () {
        if ( $().appear ) {
            var $section = $('.art-addon-progress').appear(function() {

                function runBars() {
                    var bar = $('.progress-animate');
                    var bar_width = $(this);
                    $(function(){
                        $(bar).each(function(){
                            bar_width = $(this).attr('data-valuenow');
                            $(this).width(bar_width + '%');

                            $(this).parents('.art-addon-progress').find('.perc').addClass('show').width(bar_width + '%');
                        });
                    });
                }

                runBars();
            });
        }
    };

    var accordion = function () {
        try {
            $('.js-call-accordion').each(function(){
                var wraper = $(this);
                var items = $(this).find('.js-dropdown');

                $(items).each(function(){
                    var item = $(this);

                    if($(item).hasClass('active-dropdown')) {
                        $(item).find('.icon').html('-');
                        $(item).find('.js-dropdown-content').show();
                    }
                    else {
                        $(item).find('.icon').html('+');
                        $(item).find('.js-dropdown-content').hide();
                    }

                    $(item).find('.js-toggle-dropdown').on('click', function(){
                        $(items).find('.icon').html('+');
                        if(!$(item).hasClass('active-dropdown')) {
                            $(item).find('.icon').html('-');
                            $(items).removeClass('active-dropdown');
                            $(items).find('.js-dropdown-content').slideUp();

                            $(item).toggleClass('active-dropdown');
                            $(item).find('.js-dropdown-content').slideDown();
                        }
                        else {
                            $(item).find('.icon').html('+');
                            $(items).removeClass('active-dropdown');
                            $(items).find('.js-dropdown-content').slideUp();
                        }
                    });
                })

            });
        } catch(er) {console.log(er);}
    };

    var pricing_tab = function() {
        $('.art-addon-pricing-table.layout-default').each(function () {
            var $naviBtn = $(this).find('.pricing_tab .pricing_tab_btn');
            var $content = $(this).find('.package-content');

            $($naviBtn).on('click', function(e){
                e.preventDefault();

                $($naviBtn).removeClass('active');
                $(this).addClass('active');

                $($content).find('.item-pricing').removeClass('active');
                $($content).find($(this).attr('href')).addClass('active');
            });
        });
    };

    var isotope_fnc = function() {
        try {
            // init Isotope
            var $grid = $('.grid').isotope({
                // options
                itemSelector: '.grid-item',
                layoutMode: 'masonry',
                masonry: {
                    gutterWidth: 10
                }
            });
            // filter items on button click
            $('.filters').on( 'click', 'a', function() {
                $('.filters').find('.active').removeClass('active');
                $(this).addClass('active');
                var filterValue = $(this).attr('data-filter');
                $grid.isotope({ filter: filterValue });
                return false;
            });
        } catch(er) {console.log(er);}
    };

    /**
     * thim-tabs
     */
    var call_tabs = function() {
        try {
            $('.js-call-tabs').each(function(){
                var navTabs     = $(this).find('.nav_tabs');
                var contentTabs = $(this).find('.content_tabs');

                $(contentTabs).find('.tab_panel').hide();

                var getPanelActive = $(navTabs).find('.item_nav.active').data('panel');

                $(contentTabs).find(".tab_panel[data-nav='" + getPanelActive + "']").show();
                $(contentTabs).find(".tab_panel[data-nav='" + getPanelActive + "']").addClass('active');

                $(navTabs).find('.item_nav').each(function(){
                    $(this).on('click', function(){
                        var getPanel = $(this).data('panel');

                        $(contentTabs).find('.tab_panel').hide();
                        $(contentTabs).find('.tab_panel').removeClass('active');
                        $(navTabs).find('.item_nav').removeClass('active');

                        $(contentTabs).find(".tab_panel[data-nav='" + getPanel + "']").show();
                        $(contentTabs).find(".tab_panel[data-nav='" + getPanel + "']").addClass('active');
                        $(this).addClass('active');
                    });
                });

            });
        } catch(er) {console.log(er);}
    };

    /**
     * switch menu categories
     */
    var switch_menu_cats = function() {
        try {
            $('.menu-categories').on('click', '.cat-item', function () {
                var id = $(this).data('cat');
                $('.menu-categories').find('.cat-item').removeClass('active');
                $(this).addClass('active');
                $('.group_menu').removeClass('active');
                $('.group_menu.cat_'+id).addClass('active');
            });
        } catch(er) {console.log(er);}
    };

    // Dom Ready
    $(document).ready(function () {
        spacer();
        counter_box.init();
        switch_menu_cats();
        slick_slider();
        element_responsive();
        magnificpopup();
        magnificpopup_gallery();
        magnificpopup_image();
        accordion();
        pricing_tab();
        $( window ).load(function() {
            process_fnc();
            isotope_fnc();
            call_tabs();
        });
    });

    /**
     * wow js
     */
    new WOW().init();

})(jQuery);

