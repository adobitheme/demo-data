<div class="wrap-shortcode">
    <div class="wrap_tabs js-call-tabs">

        <ul class="nav_tabs">
            <?php
            $i = 1;
            foreach ($tabs as $tab) {
                ?>
                <li class="item_nav <?php if($i==1) echo 'active';?>" data-panel="<?php echo esc_attr($i); ?>">
                    <?php echo esc_html($tab['title']) ?>
                </li>
                <?php
                $i++;
            }
            ?>
        </ul>

        <div class="content_tabs">
            <?php
            $j = 1;
            foreach ($tabs as $tab) {

                ?>
                <div class="tab_panel" data-nav="<?php echo esc_attr($j); ?>">

                    <div class="content">
                        <?php echo rawurldecode( base64_decode( $tab['description'] ) );?>
                    </div>

                </div>
                <?php
                $j++;
            }
            ?>

        </div>
    </div>
</div>