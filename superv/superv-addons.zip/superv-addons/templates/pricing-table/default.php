<div class="wrap-shortcode">
    <div class="package-content">
        <?php
        foreach ($list_table as $package):
            $featured = ( isset($package['item_featured']) && $package['item_featured'] == 'yes' ) ? 'item_featured' : '';
            ?>
            <div class="item-pricing <?php echo $featured;?>">
                <?php if($featured == 'item_featured') {?>
                    <span class="speacial"><?php echo esc_html__('Special', 'superv-addons');?></span>
                <?php }?>
                <div class="item-wrap">
                    <div class="package-head">
                        <?php if ( ! empty( $package['price'] ) ) { ?>
                            <div class="price">
                                <?php echo $package['original_price'];?>
                                <span class="current-price"><?php echo ent2ncr( $package['price'] ); ?></span>
                            </div>
                        <?php } ?>
                        <?php if ( ! empty( $package['name'] ) ) { ?>
                            <h4 class="title"><?php echo ent2ncr( $package['name'] ); ?></h4>
                        <?php } ?>
                    </div>

                    <?php if ( ! empty( $package['content_pricing'] ) ) { ?>
                        <div class="package-main">
                            <?php echo $package['content_pricing'];?>
                        </div>
                    <?php } ?>

                    <?php if ( isset( $package['image_pricing'] ) ) {
                        $image = wp_get_attachment_image_src( $package['image_pricing'], 'full' );
                        if ( $image ) {
                            echo '<img src="' . $image[0] . '" width="' . $image[1] . '" height="' . $image[2] . '" alt="' . esc_attr__( 'Image', 'superv-addons' ) . '">';
                        }
                    } ?>

                    <div class="package-footer">
                        <?php
                        if( !empty($package['item_link']) ) {
                            if ( art_plugin_active( 'js_composer/js_composer.php' ) ) {
                                $link = vc_build_link($package['item_link']);
                            } else {
                                $link = $package['item_link'];
                            }
                            ?>
                            <?php if ( ! empty( $link ) ) { ?>
                                <div class="button">
                                    <a class="readmore" href="<?php echo esc_url( $link['url'] ); ?>">
                                        <?php echo ent2ncr( $link['title'] ); ?>
                                    </a>
                                </div>
                            <?php }
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php
        endforeach;
        ?>
    </div>
</div>