<div class="wrap-shortcode">
    <div class="row">
        <?php
        foreach ($teams as $team):
            ?>
            <div class="col-lg-6 col-sm-6">
                <div class="wrap-item">
                    <div class="item-team">
                        <div class="image">
                            <?php
                            $thumbnail_id = (int) $team['image'];
                            echo art_feature_image( $thumbnail_id, 'full', 370, 360 );
                            ?>
                            <div class="socials">
                                <?php
                                if ( art_plugin_active( 'js_composer/js_composer.php' ) ) {
                                    $contacts = (array) vc_param_group_parse_atts($team['socials']);
                                    foreach ($contacts as $contact):
                                        $icon = art_get_icon_class( $contact, 'item_icon' );
                                        if ( $icon && $contact['item_icon_type'] != '' ) {
                                            vc_icon_element_fonts_enqueue( $contact['item_icon_type'] );
                                            ?>
                                            <a href="<?php echo esc_url(!empty($contact['item_link_socials']) ? esc_url($contact['item_link_socials']) : '#'); ?>">
                                                <i class="<?php echo esc_attr($icon);?>"></i>
                                            </a>
                                            <?php
                                        }
                                    endforeach;
                                } elseif ( art_plugin_active( 'elementor/elementor.php' ) ) {
                                    ?>
                                    <a href="<?php echo esc_url(!empty($team['link_fb']) ? esc_url($team['link_fb']) : '#'); ?>">
                                        <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-fb.png" alt="">
                                    </a>
                                    <a href="<?php echo esc_url(!empty($team['link_tw']) ? esc_url($team['link_tw']) : '#'); ?>">
                                        <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-tw.png" alt="">
                                    </a>
                                    <a href="<?php echo esc_url(!empty($team['link_g']) ? esc_url($team['link_g']) : '#'); ?>">
                                        <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-in.png" alt="">
                                    </a>
                                    <a href="<?php echo esc_url(!empty($team['link_in']) ? esc_url($team['link_in']) : '#'); ?>">
                                        <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-pin.png" alt="">
                                    </a>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <div class="content">
                            <h3 class="name"><?php echo esc_html( $team['name'] ); ?></h3>
                            <span class="job"><?php echo esc_html( $team['works'] ); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        endforeach;
        ?>
    </div>
</div>