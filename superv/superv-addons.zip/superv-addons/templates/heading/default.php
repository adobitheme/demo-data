<div class="wrap-shortcode"<?php echo $style_wrap;?>>
    <?php
    if( $shortcode['sub_title'] ) {
        ?>
        <div class="sub_title"<?php echo $style_sub_title;?>><?php echo ent2ncr( $shortcode['sub_title'] );?></div>
        <?php
    }
    if( $shortcode['title'] ) {
        ?>
        <h3 class="title"<?php echo $style_title;?>><?php echo ent2ncr( $shortcode['title'] );?></h3>
        <?php
    }
    if( $shortcode['description'] ) {
        ?>
        <div class="description"<?php echo $style_description;?>><?php echo ent2ncr( $shortcode['description'] );?></div>
        <?php
    }
    ?>
</div>