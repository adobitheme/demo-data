<div class="wrap-shortcode">
    <div class="menu_cat_slider js-call-slick-slide" data-numofslide="4" data-numofscroll="1" data-loopslide="1" data-autoscroll="1" data-speedauto="5000" data-respon="[4, 1], [4, 1], [3, 1], 2, 1], [1, 1]">
        <div class="slide-slick">
            <?php
            foreach ( $terms as $term ) {
                $menu_image   = get_term_meta( $term->term_id, 'art_menu_thumbnail', true );
                ?>
                <div class="item-slick">
                    <div class="wrap-item">
                        <?php
                        if( $menu_image ) {
                            echo '<div class="image-wrap" style="background-image: url('.$menu_image['url'].');">';
                            echo '</div>';
                        }
                        ?>
                        <div class="content">
                            <h3 class="title">
                                <a href="<?php echo esc_url( get_term_link( $term ) );?>"><?php echo $term->name;?></a>
                            </h3>
                            <div class="description">
                                <?php echo $term->description;?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
        <div class="wrap-arrow-slick">
            <div class="prev-slick">
                <i class="ion-ios-arrow-left"></i>
            </div>
            <div class="next-slick">
                <i class="ion-ios-arrow-right"></i>
            </div>
        </div>
    </div>
</div>