<?php
$query = array(
    'posts_per_page'      => $shortcode['number'],
    'post_type'           => 'services',
    'no_found_rows'       => true,
    'post_status'         => 'publish',
    'ignore_sticky_posts' => true,
);
$query = new WP_Query( $query );
?>
<div class="wrap-shortcode">
    <div class="row">
        <?php while ( $query->have_posts() ) : $query->the_post(); ?>
        <div class="col-lg-3 col-sm-6 col-md-6">
            <div class="wrap-item">
                <?php if( has_post_thumbnail() ) {?>
                    <div class="image">
                        <?php echo art_feature_image( get_post_thumbnail_id(), 'full', 750, 550 );?>
                    </div>
                <?php }?>
                <div class="content">
                    <h3 class="title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
                    <div class="description"><?php echo rwmb_meta( 'art_service_desc' );?></div>
                </div>
            </div>
        </div>
        <?php endwhile;?>
    </div>
</div>