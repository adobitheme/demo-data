<?php
$query = array(
    'posts_per_page'      => $shortcode['number'],
    'post_type'           => 'galleries',
    'no_found_rows'       => true,
    'post_status'         => 'publish',
    'ignore_sticky_posts' => true,
);
$query = new WP_Query( $query );
?>
<div class="wrap-shortcode grid">
    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
        <div class="item grid-item">
            <div class="wrap-item">
                <div class="post-thumb">
                    <?php the_post_thumbnail('full');?>
                    <?php
                    $images = get_post_gallery_images( get_the_ID() );
                    ?>
                </div>
                <div class="icon-thumb" data-id="<?php echo get_the_ID();?>">
                    <i class="ion-android-add"></i>
                </div>
            </div>
        </div>
    <?php
    endwhile;
    ?>
</div>
<div class="gallery_show"></div>