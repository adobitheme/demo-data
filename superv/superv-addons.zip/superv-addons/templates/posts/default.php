<?php
$query = array(
    'posts_per_page'      => $shortcode['number'],
    'no_found_rows'       => true,
    'post_status'         => 'publish',
    'ignore_sticky_posts' => true,
);
$query = new WP_Query( $query );
?>
<div class="row">
    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
        <div class="col-sm-6">
            <div class="post-item">
                <div class="post-image">
                    <a href="<?php the_permalink();?>">
                        <?php echo art_feature_image( get_post_thumbnail_id(), 'full', 570, 370 );?>
                    </a>
                    <div class="date">
                        <?php echo get_the_date('d F');?>
                    </div>
                </div>
                <div class="post-text">

                    <h4 class="title"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h4>
                    <div class="desc">s
                        <?php echo wp_trim_words(get_the_content(), 28,''); ?>
                    </div>
                    <a href="<?php the_permalink(); ?>" class="read-more"><?php echo esc_html('Read More','vizac-addons'); ?></a>
                </div>
            </div>
        </div>
    <?php
    endwhile;
    ?>
</div>