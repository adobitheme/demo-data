<div class="wrap-addon">
    <div class="brands_slider js-call-slick-slide" data-numofshow="5" data-numofscroll="1" data-loopslide="1" data-autoscroll="1" data-speedauto="5000" data-respon="[5, 1], [5, 1], [4, 1], 2, 1], [2, 1]">
        <div class="slide-slick">
            <?php
            foreach ($brands as $brand):
                ?>
                <div class="item-slick item_brand">
                    <?php if ( isset( $brand['image'] ) ) {
                        $logo = wp_get_attachment_image_src( $brand['image'], 'full' );
                        $img  = '';
                        if ( $logo ) {
                            $img = '<img src="' . $logo[0] . '" width="' . $logo[1] . '" height="' . $logo[2] . '" alt="' . esc_attr__( 'Logo', 'builderpress' ) . '">';
                        }

                        if ( $img ) {
                            $link = isset( $brand['item_link'] ) ? $brand['item_link'] : array();
                            if ( ! empty( $link['url'] ) ) { ?>
                                <a href="<?php echo esc_url( $link['url'] ); ?>" <?php echo bp_template_build_link( $link ); ?>>
                                    <?php echo ent2ncr( $img ); ?>
                                </a>
                            <?php } else {
                                echo ent2ncr( $img );
                            }
                        }
                    } ?>
                </div>
            <?php
            endforeach;
            ?>
        </div>
    </div>
</div>