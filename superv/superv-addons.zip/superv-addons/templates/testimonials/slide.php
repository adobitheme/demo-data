<?php
$number = !empty($shortcode['number']) ? $shortcode['number'] : 1;
?>
<div class="wrap-addon">
    <div class="testimonials_slider js-call-slick-slide" data-numofslide="<?php echo $number;?>" data-numofscroll="1" data-loopslide="1" data-autoscroll="1" data-speedauto="5000" data-respon="[<?php echo $number;?>, 1], [<?php echo $number;?>, 1], [1, 1], 1, 1], [1, 1]">
        <div class="slide-slick">
            <?php
            foreach ($testimonials as $item):
                ?>
                <div class="item-slick">
                    <div class="wrap-item">
                        <div class="description"><?php echo $item['description'];?></div>
                        <div class="info">
                            <div class="avatar">
                                <?php
                                $thumbnail_id = (int) $item['image'];
                                echo art_feature_image( $thumbnail_id, 'full', 75, 75 );
                                ?>
                            </div>
                            <div class="rate">
                                <h3 class="name"><?php echo $item['name'];?></h3>
                                <div class="work"><?php echo $item['works'];?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            endforeach;
            ?>
        </div>
    </div>
</div>