<div class="wrap-shortcode">
    <?php
    foreach ($item_features  as $item ):
        ?>
        <div class="item">
            <div class="content">
                <h3 class="title"><?php echo $item['title'];?></h3>
                <span><?php echo $item['description'];?></span>
            </div>
        </div>
    <?php
    endforeach;
    ?>
</div>