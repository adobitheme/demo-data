<?php
// Style wrap
$style_item = ( !empty( $shortcode['height'] ) ) ? ' height: ' . $shortcode['height']['size'] . 'px;' : '';
if( !empty($shortcode['background_image']) ) {
    $image_url = wp_get_attachment_image_src( $shortcode['background_image'], 'full' );
    if( $image_url ) {
        $style_item .= ( $image_url ) ? ' background-image: url('.$image_url[0].')' : '';
    }
}
$style_item = $style_item ? ' style="' . $style_item . '"' : '';
?>
<div class="wrap-shortcode"<?php echo $style_item;?>>
    <?php if(  $shortcode['video_url'] ) :?>
    <div class="icon_play">
        <a href="<?php echo $shortcode['video_url'];?>" class="video_popup"><img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-play.png" alt=""></a>
    </div>
    <?php endif;?>
</div>