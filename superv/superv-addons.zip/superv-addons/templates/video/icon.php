<div class="wrap-shortcode">
    <?php if(  $shortcode['video_url'] ) :?>
    <div class="icon_play">
        <a href="<?php echo $shortcode['video_url'];?>" class="video_popup">
            <?php if( !empty($shortcode['background_image']) ) {
                $image_url = wp_get_attachment_image_src( $shortcode['background_image'], 'full' );
                echo ( $image_url ) ? '<img src="'.$image_url[0].'" alt="">' : '<img src="'.ART_ADDONS_URL.'/assets/images/icon-play.png" alt="">';
                ?>
            <?php } else {?>
                <img src="<?php echo ART_ADDONS_URL;?>/assets/images/icon-play.png" alt="">
            <?php }?>
        </a>
    </div>
    <?php endif;?>
</div>