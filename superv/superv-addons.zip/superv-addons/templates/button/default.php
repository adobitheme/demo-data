<?php if( $link ) : $title = $link['title'] ? $link['title'] : __( 'Button', 'superv-addons' );?>
<div class="wrap-shortcode">
    <h3>
        <a href="<?php echo esc_url( $link['url'] ); ?>">
            <?php echo ent2ncr( $title ); ?>
        </a>
    </h3>
</div>
<?php endif; ?>