<div class="wrap-shortcode">
    <?php if( $shortcode['show_filter'] == 'yes' ) {?>
        <div class="menu-categories">
            <?php
            $i = 0;
            foreach ( $terms as $term ) {
                $i++;
                $term_ids[] = $term->term_id;
                $menu_icon   = get_term_meta( $term->term_id, 'art_menu_icon', true );
                ?>
                <div class="cat-item<?php echo ($i==1) ? ' active' : '';?>" data-cat="<?php echo $term->term_id;?>">
                    <div class="cat-wrap">
                        <?php
                        if( $menu_icon ) {
                            echo '<div class="image-wrap">';
                            echo '<img src="'.$menu_icon['url'].'" alt="">';
                            echo '</div>';
                        }
                        ?>
                        <h3 class="title">
                            <?php echo $term->name;?> (<?php echo $term->count;?>)
                        </h3>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    <?php }?>
    <div class="menu">
        <?php
        $term_ids = $shortcode['menu_categories'];
        if( $term_ids ) {
            for ($i=0;$i<count($term_ids);$i++) {
                ?>
                <div class="group_menu columns_<?php echo $shortcode['columns'];?> cat_<?php echo $term_ids[$i];?><?php echo ($i==0) ? ' active' : '';?>">
                    <?php
                    $query = array(
                        'posts_per_page'      => $shortcode['number'],
                        'post_type'           => 'menu',
                        'no_found_rows'       => true,
                        'post_status'         => 'publish',
                        'ignore_sticky_posts' => true,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'menu-cat',
                                'field'    => 'id',
                                'terms'    => $term_ids[$i],
                            ),
                        ),
                    );
                    $query = new WP_Query( $query );
                    ?>
                    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                        <div class="menu-item">
                            <div class="menu-wrap">
                                <?php
                                if( rwmb_meta( 'art_menu_type' ) ) {
                                    switch ( rwmb_meta( 'art_menu_type' ) ) {
                                        case "hot":
                                            echo '<span class="menu_type">'.esc_html__('Hot Sell', 'superv-addons').'</span>';
                                            break;
                                        case "recommend":
                                            echo '<span class="menu_type">'.esc_html__('Recommended', 'superv-addons').'</span>';
                                            break;
                                        case "new":
                                            echo '<span class="menu_type">'.esc_html__('New Sell', 'superv-addons').'</span>';
                                            break;
                                    }
                                }
                                ?>
                                <div class="image-menu">
                                    <?php echo art_feature_image( get_post_thumbnail_id(), 'full', 150, 80 );?>
                                </div>
                                <div class="content-menu">
                                    <h3 class="title">
                                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                    </h3>
                                    <span><?php echo wp_trim_words(get_the_content(), 20,''); ?></span>
                                </div>
                                <div class="price-menu">
                                    <?php if( rwmb_meta( 'art_menu_price' ) ) {?>
                                        <h4><?php echo rwmb_meta( 'art_menu_price' );?></h4>
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    <?php
                    endwhile;
                    wp_reset_query();
                    ?>
                </div>
                <?php
            }
        } else {
            $query = array(
                'posts_per_page'      => $shortcode['number'],
                'post_type'           => 'menu',
                'no_found_rows'       => true,
                'post_status'         => 'publish',
                'ignore_sticky_posts' => true,
            );
            $query = new WP_Query( $query );
            ?>
            <div class="group_menu columns_<?php echo $shortcode['columns'];?> active">
                <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                    <div class="menu-item">
                        <div class="menu-wrap">
                            <?php
                            if( rwmb_meta( 'art_menu_type' ) ) {
                                switch ( rwmb_meta( 'art_menu_type' ) ) {
                                    case "hot":
                                        echo '<span class="menu_type">'.esc_html__('Hot Sell', 'superv-addons').'</span>';
                                        break;
                                    case "recommend":
                                        echo '<span class="menu_type">'.esc_html__('Recommended', 'superv-addons').'</span>';
                                        break;
                                    case "new":
                                        echo '<span class="menu_type">'.esc_html__('New Sell', 'superv-addons').'</span>';
                                        break;
                                }
                            }
                            ?>
                            <div class="image-menu">
                                <?php echo art_feature_image( get_post_thumbnail_id(), 'full', 150, 80 );?>
                            </div>
                            <div class="content-menu">
                                <h3 class="title">
                                    <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                </h3>
                                <span><?php echo wp_trim_words(get_the_content(), 20,''); ?></span>
                            </div>
                            <div class="price-menu">
                                <?php if( rwmb_meta( 'art_menu_price' ) ) {?>
                                    <h4><?php echo rwmb_meta( 'art_menu_price' );?></h4>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
            </div>
            <?php
        }
        ?>
    </div>
</div>