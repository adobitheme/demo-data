<div class="wrap-shortcode">
    <?php
    $i=0;
    foreach ($accodion  as $item ):
        $i++;
        ?>
        <div class="item js-dropdown <?php if($i==1) echo 'active-dropdown';?>">
            <div class="question js-toggle-dropdown">
                <span class="item-number"><?php echo $i; ?>.</span><?php echo esc_html($item['title']); ?>
                <span class="icon">+</span>
            </div>

            <div class="answer js-dropdown-content">
                <?php echo esc_html($item['description']); ?>
            </div>
        </div>
    <?php
    endforeach;
    ?>
</div>