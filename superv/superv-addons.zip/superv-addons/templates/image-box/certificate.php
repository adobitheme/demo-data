<div class="wrap-shortcode">
    <?php
    if( !empty($shortcode['image']) ) {
        $image_url = wp_get_attachment_image_src( $shortcode['image'], 'full' );
        if( $image_url ) {
            echo '<div class="image"><img src="'.$image_url[0].'" alt=""></div>';
        }
    }
    ?>
    <div class="content">
        <?php if($shortcode['title']) {?>
            <h3 class="title"><?php echo $shortcode['title'];?></h3>
        <?php }?>
        <?php if($shortcode['sub_title']) {?>
            <span class="sub_title"><?php echo $shortcode['sub_title'];?></span>
        <?php }?>
        <?php if($shortcode['description']) {?>
            <span class="description"><?php echo $shortcode['description'];?></span>
        <?php }?>
    </div>
</div>