<?php
// Style wrap
$style_item = ( !empty( $shortcode['height'] ) ) ? ' height: ' . $shortcode['height']['size'] . 'px;' : '';
if( !empty($shortcode['image']) ) {
    $image_url = wp_get_attachment_image_src( $shortcode['image'], 'full' );
    if( $image_url ) {
        $style_item .= ( $image_url ) ? ' background-image: url('.$image_url[0].')' : '';
    }
}
$style_item = $style_item ? ' style="' . $style_item . '"' : '';
?>
<div class="wrap-shortcode"<?php echo $style_item;?>>
    <?php if($shortcode['title']) {?>
        <h3 class="title"><?php echo $shortcode['title'];?></h3>
    <?php }?>
</div>