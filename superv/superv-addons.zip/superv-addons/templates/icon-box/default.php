<div class="wrap-shortcode">
    <div class="wrap-icon">
        <?php
        if( $shortcode['icon_type'] == 'image' ) {
            $icon = wp_get_attachment_image_src( $shortcode['custom_image'], 'full' );
            ?>
            <div class="type-image">
                <?php
                if ( $icon ) {
                    echo '<img class="icon-color" src="' . $icon[0] . '" width="' . $icon[1] . '" height="' . $icon[2] . '" alt="' . esc_attr__( 'Image', 'vizac-addons' ) . '">';
                }
                ?>
            </div>
            <?php
        } else {
            $icon = art_get_icon_class( $shortcode, 'icon' );
            if ( $icon && $shortcode['icon_type'] != '' ) {
                //vc_icon_element_fonts_enqueue( $shortcode['icon_type'] );
                ?>
                <div class="type-icon">
                    <i class="<?php echo esc_attr($icon);?>"></i>
                </div>
                <?php
            }
        }
        ?>
    </div>
    <div class="content">
        <?php
        if( $shortcode['title'] ) {
            ?>
            <h3 class="title">
                <?php if( $link['url'] ) :?>
                    <a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo $shortcode['title'];?></a>
                <?php else: ?>
                    <?php echo $shortcode['title'];?>
                <?php endif;?>
            </h3>
            <?php
        }
        if( $shortcode['description'] ) {
            ?>
            <div class="description"><?php echo ent2ncr( $shortcode['description'] );?></div>
            <?php
        }
        ?>
    </div>
</div>