<?php
/*
 * Import Demo
 */
function art_import_files() {
    return array(
        array(
            'import_file_name'             => 'Demo 1',
            'local_import_file'            => 'https://github.com/adobitheme/demo-data/raw/master/superv/demo-el-1/content.xml',
            'local_import_widget_file'     => 'https://github.com/adobitheme/demo-data/raw/master/superv/demo-el-1/widget_data.json',
            'local_import_customizer_file' => 'https://github.com/adobitheme/demo-data/raw/master/superv/demo-el-1/superv-export.dat',
            'import_preview_image_url'     => 'https://github.com/adobitheme/demo-data/raw/master/superv/demo-el-1/screenshot.jpg',
            'import_notice'                => esc_html__( 'The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'superv-addons' ),
        ),
    );
}
add_filter( 'pt-ocdi/import_files', 'art_import_files' );

function art_ocdi_after_import($selected_import) {
    /************************************************************************
     * Import slider(s) for the current demo being imported
     *************************************************************************/
    if ( class_exists( 'RevSlider' ) ) {
        if ( 'Demo 1' === $selected_import['import_file_name'] ) {
            $slider_import = 'https://github.com/adobitheme/demo-data/raw/master/superv/demo-el-1/slide.zip';
        }
        if ( file_exists( $slider_import ) ) {
            $slider = new RevSlider();
            $slider->importSliderFromPost( true, true, $slider_import );
        }
    }
    /************************************************************************
     * Setting Menus
     *************************************************************************/
    $main_menu   = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
        'primary'   => $main_menu->term_id,
    ));
    /************************************************************************
     * Set Home Page
     *************************************************************************/
    $front_page = get_page_by_title( 'Home' );
    $blog_page = get_page_by_title( 'Blog' );
    if(isset( $front_page ) && $front_page->ID) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $front_page->ID);
    }
    /************************************************************************
     * Set Blog Page
     *************************************************************************/
    if(isset( $blog_page ) && $blog_page->ID) {
        update_option('page_for_posts', $blog_page->ID);
    }
    $option_permalink = get_option('permalink_structure');
    if( isset($option_permalink) ) {
        update_option( 'permalink_structure', '/%postname%/' );
    } else {
        add_option( 'permalink_structure', '/%postname%/' );
    }
}
// Uncomment the below
add_action( 'pt-ocdi/after_import', 'art_ocdi_after_import');