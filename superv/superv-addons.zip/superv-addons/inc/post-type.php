<?php
/*
* Creating a function to create our CPT
*/

function art_custom_post_type() {

    // Set UI labels for Menu
    $labels = array(
        'name'                => _x( 'Menu', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Menu', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Menu', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Menu', 'twentythirteen' ),
        'all_items'           => __( 'All Menu', 'twentythirteen' ),
        'view_item'           => __( 'View Menu', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New Menu', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Menu', 'twentythirteen' ),
        'update_item'         => __( 'Update Menu', 'twentythirteen' ),
        'search_items'        => __( 'Search Menu', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),
    );
    $args = array(
        'labels'        => $labels,
        'rewrite'       => array( 'slug' => 'menu' ),
        'menu_icon'     => 'dashicons-format-image',
        'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'public'        => true
    );
    register_post_type( 'menu', $args );

    // Set UI labels for Services
    $labels = array(
        'name'                => _x( 'Services', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Service', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Services', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Service', 'twentythirteen' ),
        'all_items'           => __( 'All Services', 'twentythirteen' ),
        'view_item'           => __( 'View Service', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New Service', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Service', 'twentythirteen' ),
        'update_item'         => __( 'Update Service', 'twentythirteen' ),
        'search_items'        => __( 'Search Service', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),
    );
    $args = array(
        'labels'        => $labels,
        'rewrite'       => array( 'slug' => 'services' ),
        'menu_icon'     => 'dashicons-admin-generic',
        'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'public'        => true
    );
    register_post_type( 'services', $args );

    // Set UI labels for Menu
    $labels = array(
        'name'                => _x( 'Galleries', 'Post Type General Name', 'twentythirteen' ),
        'singular_name'       => _x( 'Galleries', 'Post Type Singular Name', 'twentythirteen' ),
        'menu_name'           => __( 'Galleries', 'twentythirteen' ),
        'parent_item_colon'   => __( 'Parent Galleries', 'twentythirteen' ),
        'all_items'           => __( 'All Galleries', 'twentythirteen' ),
        'view_item'           => __( 'View Galleries', 'twentythirteen' ),
        'add_new_item'        => __( 'Add New Galleries', 'twentythirteen' ),
        'add_new'             => __( 'Add New', 'twentythirteen' ),
        'edit_item'           => __( 'Edit Galleries', 'twentythirteen' ),
        'update_item'         => __( 'Update Galleries', 'twentythirteen' ),
        'search_items'        => __( 'Search Galleries', 'twentythirteen' ),
        'not_found'           => __( 'Not Found', 'twentythirteen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentythirteen' ),
    );
    $args = array(
        'labels'        => $labels,
        'rewrite'       => array( 'slug' => 'galleries' ),
        'menu_icon'     => 'dashicons-format-image',
        'supports'      => array( 'title', 'editor', 'post-formats', 'thumbnail' ),
        'public'        => true
    );
    register_post_type( 'galleries', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not
* unnecessarily executed.
*/

add_action( 'init', 'art_custom_post_type', 0 );

/**
 * Register taxonomy for post type.
 *
 * @see register_post_type() for registering post types.
 */
function art_register_private_taxonomy() {
    $args = array(
        'label'        => __( 'Menu Category', 'superv-addons' ),
        'public'       => true,
        'rewrite'      => false,
        'hierarchical' => true
    );

    register_taxonomy( 'menu-cat', 'menu', $args );
}
add_action( 'init', 'art_register_private_taxonomy', 10 );

if( art_plugin_active( 'meta-box/meta-box.php' ) ) {
    add_filter( 'rwmb_meta_boxes', 'art_register_meta_boxes' );
    function art_register_meta_boxes( $meta_boxes ) {
        $meta_boxes[] = array(
            'title'      => 'Menu setting',
            'post_types' => 'menu',

            'fields' => array(
                array(
                    'name'  => 'Type',
                    'id'    => 'art_menu_type',
                    'type'  => 'radio',
                    'options' => array(
                        '' => 'None',
                        'hot' => 'Hot',
                        'new' => 'New',
                        'recommend' => 'Recommended',
                    ),
                ),
                array(
                    'name'  => 'Price',
                    'id'    => 'art_menu_price',
                    'type'  => 'text',
                ),
            )
        );

        $meta_boxes[] = array(
            'title'      => 'Service setting',
            'post_types' => 'services',

            'fields' => array(
                array(
                    'name'  => 'Icon',
                    'id'    => 'art_service_icon',
                    'type'  => 'text',
                ),
                array(
                    'name'  => 'Description',
                    'id'    => 'art_service_desc',
                    'type'  => 'textarea',
                ),
            )
        );

        // Add more meta boxes if you want
        // $meta_boxes[] = ...

        return $meta_boxes;
    }
}