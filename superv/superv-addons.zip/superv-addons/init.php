<?php 
/*
Plugin Name: Superv Addons
Plugin URI: http://adobitheme.com/plugins/
Description: Extend Elementor and Visual Composer with Advanced Shortcodes.
Version: 1.0
Author: ArtThemes
Author URI: http://adobitheme.com
*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ART_ADDONS_FILE', __FILE__ );
define( 'ART_ADDONS_PATH', dirname( __FILE__ ) . '/' );
define( 'ART_ADDONS_URL', plugins_url( '', __FILE__ ) . '/' );

/**
 * Add Aq Resize
 */
require_once(ART_ADDONS_PATH . '/inc/libs/aq_resizer.php');

// Enqueue scripts
add_action( 'wp_enqueue_scripts', 'loadCssAndJs', 99999 );
function loadCssAndJs() {
	wp_enqueue_script( 'at-shortcode-js', plugins_url('assets/js/shortcodes.js', __FILE__), array('jquery'), '1.0', true );
    // Counter
    wp_register_script( 'counters-script', plugins_url('assets/js/countto.js', __FILE__), array(), '1.0' );
    // Magnific popup
    //wp_enqueue_script( 'magnific-popup-css', plugins_url('assets/libs/magnific-popup/magnific-popup.css', __FILE__) );
    wp_enqueue_script( 'magnific-popup-jquery', plugins_url('assets/libs/magnific-popup/jquery.magnific-popup.min.js', __FILE__) );
    // Appear
    wp_enqueue_script( 'appear-jquery', plugins_url('assets/libs/appear/appear.js', __FILE__) );
    // Slick
    wp_register_script( 'slick-script', plugins_url('assets/libs/slick/slick.min.js', __FILE__) );
    wp_register_style( 'slick-css', plugins_url('assets/libs/slick/slick.css', __FILE__) );
    // Isotope
    wp_enqueue_script( 'isotope-script', plugins_url('assets/libs/isotope/isotope.pkgd.min.js', __FILE__) );
    // waypoints
    wp_enqueue_script( 'waypoints-script', plugins_url('assets/libs/waypoints/jquery.waypoints.min.js', __FILE__) );
    // Animate
    wp_enqueue_style( 'animate-css', plugins_url('assets/libs/animate/animate.css', __FILE__) );
    wp_enqueue_script( 'wow-script', plugins_url('assets/libs/animate/wow.min.js', __FILE__) );
    // datetimepicker
    wp_enqueue_style( 'datetime-picker-css', plugins_url('assets/libs/datetimepicker/jquery.datetimepicker.min.css', __FILE__) );
    wp_enqueue_script( 'datetime-picker-script', plugins_url('assets/libs/datetimepicker/jquery.datetimepicker.full.min.js', __FILE__) );
    // Icon
    wp_register_style( 'font-articon', plugins_url('assets/libs/font-articon/art-icon.css', __FILE__) );
    // Style
    wp_enqueue_style( 'at-style-css', plugins_url('assets/css/style.css', __FILE__), array() );
}

add_action( 'vc_base_register_admin_css', 'art_vc_admin_css' );
function art_vc_admin_css(){
    wp_enqueue_style('admin-css', plugin_dir_url( __FILE__ ) . '/assets/css/style-admin.css');
    wp_enqueue_style( 'datetime-picker-css', plugins_url('assets/libs/datetimepicker/jquery.datetimepicker.min.css', __FILE__) );
}
add_action( 'vc_base_register_admin_js', 'art_vc_admin_js' );
function art_vc_admin_js(){
    wp_enqueue_script( 'datetime-picker-script', plugins_url('assets/libs/datetimepicker/jquery.datetimepicker.full.min.js', __FILE__) );
}

// register extra params
add_action( 'vc_before_init', 'art_register_extra_params' );
function art_register_extra_params() {
    if ( function_exists( 'vc_add_shortcode_param' ) ) {
        vc_add_shortcode_param( 'radio_image', 'art_radio_image_param' );
        vc_add_shortcode_param( 'number', 'art_number_param' );
        vc_add_shortcode_param( 'date', 'art_date_param' );
    }
}

/**
 * @param $settings
 * @param $value
 *
 * @return string
 */
function art_date_param( $settings, $value ) {
    $param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
    $type       = isset( $settings['type'] ) ? $settings['type'] : '';
    $class      = isset( $settings['class'] ) ? $settings['class'] : '';
    $value      = isset( $value ) ? $value : $settings['value'];
    $output     = '<input type="text" name="' . $param_name . '" class="bp-datetimepicker wpb_vc_param_value ' . $param_name . ' ' . $type . '_field ' . $class . '" value="' . $value . '"  />';
    $output     .= '<script>jQuery(\'.bp-datetimepicker\').datetimepicker();</script>';
    $output     .= '';

    return $output;
}

/**
 * @param $settings
 * @param $value
 *
 * @return string
 */
function art_radio_image_param( $settings, $value ) {
    $param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
    $type       = isset( $settings['type'] ) ? $settings['type'] : '';
    $radios     = isset( $settings['options'] ) ? $settings['options'] : '';
    $class      = isset( $settings['class'] ) ? $settings['class'] : '';
    $output     = '<input type="hidden" name="' . $param_name . '" id="' . $param_name . '" class="wpb_vc_param_value ' . $param_name . ' ' . $type . '_field ' . $class . '" value="' . $value . '"  ' . ' />';
    $output     .= '<div id="' . $param_name . '_wrap" class="icon_style_wrap ' . $class . '" >';
    if ( $radios != '' && is_array( $radios ) ) {
        $i = 0;
        foreach ( $radios as $key => $image_url ) {
            $class   = ( $key == $value ) ? ' class="selected" ' : '';
            $image   = '<img id="' . $param_name . $i . '_img' . $key . '" src="' . $image_url . '" ' . $class . '/>';
            $checked = ( $key == $value ) ? ' checked="checked" ' : '';
            $output  .= '<input name="' . $param_name . '_option" id="' . $param_name . $i . '" value="' . $key . '" type="radio" '
                . 'onchange="document.getElementById(\'' . $param_name . '\').value=this.value;'
                . 'jQuery(\'#' . $param_name . '_wrap img\').removeClass(\'selected\');'
                . 'jQuery(\'#' . $param_name . $i . '_img' . $key . '\').addClass(\'selected\');'
                . 'jQuery(\'#' . $param_name . '\').trigger(\'change\');" '
                . $checked . ' style="display:none;" />';
            $output  .= '<label for="' . $param_name . $i . '">' . $image . '</label>';
            $i ++;
        }
    }
    $output .= '</div>';

    return $output;
}

/**
 * @param $settings
 * @param $value
 *
 * @return string
 */
function art_number_param( $settings, $value ) {
    $param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
    $type       = isset( $settings['type'] ) ? $settings['type'] : '';
    $min        = isset( $settings['min'] ) ? $settings['min'] : '';
    $max        = isset( $settings['max'] ) ? $settings['max'] : '';
    $suffix     = isset( $settings['suffix'] ) ? $settings['suffix'] : '';
    $class      = isset( $settings['class'] ) ? $settings['class'] : '';
    $value      = isset( $value ) ? $value : $settings['value'];
    $output     = '<input type="number" min="' . $min . '" max="' . $max . '" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . '" name="' . $param_name . '" value="' . $value . '" style="max-width:100px; margin-right: 10px; height: auto;" />' . $suffix;

    return $output;
}

// Get Feature image use aq_resize
if ( ! function_exists( 'art_feature_image' ) ) {
    function art_feature_image( $img_id, $size = 'full', $width = null, $height = null, $alt = null, $title = null ) {
        if( empty($img_id) ) return;
        $src   = wp_get_attachment_image_src( $img_id, $size );
        $style = '';
        if ( ! $src ) {

        }
        if ( $width && $height ) {
            if ( $src[1] >= $width || $src[2] >= $height ) {
                $crop = ( $src[1] >= $width && $src[2] >= $height ) ? true : false;
                if ( $new_link = aq_resize( $src[0], $width, $height, $crop ) ) {
                    $src[0] = $new_link;
                }
            }
            $style = ' width="' . $width . '" height="' . $height . '"';
        } else {
            if ( ! empty( $src[1] ) && ! empty( $src[2] ) ) {
                $style = ' width="' . $src[1] . '" height="' . $src[2] . '"';
            }
        }
        if ( ! $alt ) {
            $alt = get_the_title( $img_id );
        }
        if ( ! $title ) {
            $title = get_the_title( $img_id );
        }
        return '<img src="' . esc_url( $src[0] ) . '" alt="' . esc_attr( $alt ) . '" title="' . esc_attr( $title ) . '" ' . $style . '>';
    }
}

/**
 * Check a plugin activate
 *
 * @param $plugin
 *
 * @return bool
 */
function art_plugin_active( $plugin ) {
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    if ( is_plugin_active( $plugin ) ) {
        return true;
    }

    return false;
}

/**
 * Define ajaxurl if not exist
 */
add_action( 'wp_head', 'art_define_ajaxurl', 1000 );
function art_define_ajaxurl() { ?>
    <script type="text/javascript">
        if (typeof ajaxurl === 'undefined') {
            /* <![CDATA[ */
            var ajaxurl = "<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>";
            /* ]]> */
        }
    </script>
    <?php
}

/**
 * Get icon font base on font icon type
 */
if ( !function_exists('art_get_icon_class') ) {
    function art_get_icon_class($atts, $icon_location)
    {
        // Define vars
        $icon = '';
        $icon_type = !empty($atts['icon_type']) ? $atts['icon_type'] : 'fontawesome';

        // Generate fontawesome icon class
        if ( ( 'awesome_5' == $icon_type || 'fontawesome' == $icon_type ) && !empty($atts[$icon_location])) {
            $icon = $atts[$icon_location];
            $icon = str_replace('fa-', '', $icon);
            $icon = str_replace('fa ', '', $icon);
            $icon = 'fa fa-' . $icon;

        } elseif (!empty($atts[$icon_location . '_' . $icon_type])) {
            $icon = $atts[$icon_location . '_' . $icon_type];
        }

        // Sanitize
        $icon = in_array($icon, array('icon', 'none')) ? '' : $icon;

        // Return icon class
        return $icon;
    }
}

/**
 * @return mixed
 */
function art_get_post_formats() {

    $status = array(
        esc_html__( 'All', 'superv-addons' )       => '',
        esc_html__( 'Standard', 'superv-addons' )  => 'standard',
        esc_html__( 'Image', 'superv-addons' ) => 'image',
        esc_html__( 'Gallery', 'superv-addons' )   => 'gallery',
        esc_html__( 'Video', 'superv-addons' )   => 'video',
    );

    return $status;
}

/**
 * Get category of post type
 */
if ( !function_exists('art_get_post_type_categories') ) {
    function art_get_post_type_categories($taxonomy)
    {
        global $wpdb;
        $categories = $wpdb->get_results( $wpdb->prepare(
            "
				  SELECT      t2.slug, t2.name
				  FROM        $wpdb->term_taxonomy AS t1
				  INNER JOIN $wpdb->terms AS t2 ON t1.term_id = t2.term_id
				  WHERE t1.taxonomy = %s
				  ",
            $taxonomy
        ) );

        $options = array( esc_html__( 'All Category', 'superv-addons' ) => '' );
        foreach ( $categories as $category ) {
            $options[ html_entity_decode( $category->name ) ] = $category->slug;
        }

        return $options;
    }
}

/**
 * Get url account page
 */
if( !function_exists('art_get_login_page_url') ) {
    function art_get_login_page_url( $redirect_url = '' ) {
        $page = get_page_by_path( 'account' );
        if( $page ) {
            return ! empty( $redirect_url ) ? add_query_arg( 'redirect_to', urlencode( $redirect_url ), get_permalink( $page[0] ) ) : get_permalink( $page->ID );
        }
        return wp_login_url();
    }
}

/**
 * Filter lost password link
 *
 * @param $url
 *
 * @return string
 */
if ( ! function_exists( 'art_get_lost_password_url' ) ) {
    function art_get_lost_password_url() {
        $url = add_query_arg( 'action', 'lostpassword', art_get_login_page_url() );
        return $url;
    }
}

/**
 * Reset password failed
 */
if ( ! function_exists( 'art_reset_password_failed' ) ) {
    function art_reset_password_failed() {
        //setup your custom URL for redirection
        $url = add_query_arg( 'action', 'lostpassword', art_get_login_page_url() );

        if ( empty( $_POST['user_login'] ) ) {
            $url = add_query_arg( 'empty', '1', $url );
            wp_redirect( $url );
            exit;
        } elseif ( strpos( $_POST['user_login'], '@' ) ) {
            $user_data = get_user_by( 'email', trim( $_POST['user_login'] ) );
            if ( empty( $user_data ) ) {
                $url = add_query_arg( 'user_not_exist', '1', $url );
                wp_redirect( $url );
                exit;
            }
        } elseif ( ! username_exists( $_POST['user_login'] ) ) {
            $url = add_query_arg( 'user_not_exist', '1', $url );
            wp_redirect( $url );
            exit;
        }
    }
}
add_action( 'lostpassword_post', 'art_reset_password_failed', 999 );

add_action( 'wp_ajax_art_get_images_gallery', 'art_get_images_gallery' );
add_action( 'wp_ajax_nopriv_art_get_images_gallery', 'art_get_images_gallery' );
/**
 * Function ajax widget images gallery
 */
if ( !function_exists( 'art_get_images_gallery' ) ) {
    function art_get_images_gallery() {
        $gal_id = $_POST["gal_id"];
        $gallery    = get_post( $gal_id );

        $format = get_post_format( $gallery->ID );

        $link  = get_edit_post_link( $gal_id );
        ob_start();

        if ( $format == 'video' ) {
            $url_video = get_post_meta( $gal_id, 'thim_video', true );
            if ( empty( $url_video ) ) {
                echo '<div class="thim-gallery-message"><a class="link" href="' . $link . '">' . esc_html__( 'This post doesn\'t have config video, please add the video!', 'eduma' ) . '</a></div>';
            }
            // If URL: show oEmbed HTML
            if ( filter_var( $url_video, FILTER_VALIDATE_URL ) ) {
                if ( $oembed = @wp_oembed_get( $url_video ) ) {
                    echo '<div class="video">' . $oembed . '</div>';
                }
            } else {
                echo '<div class="video">' . $url_video . '</div>';
            }

        } else {
            $images = get_post_gallery_images( $gal_id );
            if ( !empty( $images ) ) {
                foreach ( $images as $k => $value ) {
                    if ( $value && $value != '' ) {
                        echo '<a href="' . $value . '">';
                        echo '<img src="' . $value . '" />';
                        echo '</a>';
                    }
                }
            } else {
                $featured_img_url = get_the_post_thumbnail_url($gal_id,'full');
                echo '<a href="' . $featured_img_url . '">';
                echo '<img src="' . $featured_img_url . '" />';
                echo '</a>';
            }
        }

        $output = ob_get_contents();
        ob_end_clean();
        echo ent2ncr( $output );
        die();
    }
}

/**
 * Detect device
 */
if( !function_exists( 'art_detect_device' ) ) {
    function art_detect_device() {
        $detect = 'desktop';
        if( wp_is_mobile() ) {
            $detect = 'mobile';
            if (strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false) {
                $detect = 'tablet';
            }
        }
        return $detect;
    }
}

/**
 * Render social share
 *
 * @param $social_name
 *
 * @return string
 */
if( !function_exists('art_render_social_link') ) {
    function art_render_social_link( $social_name ) {
        global $wp;
        $url = home_url( $wp->request );
        switch ( $social_name ) {
            case 'twitter':
                echo '<a href="https://twitter.com/home?status=' . $url . '" class="icon-social twitter"><i class="ion ion-social-twitter"></i></a>';
                break;
            case 'facebook':
                echo '<a href="https://www.facebook.com/sharer/sharer.php?u=' . $url . '" class="icon-social facebook"><i class="ion ion-social-facebook"></i></a>';
                break;
            case 'google':
                echo '<a href="https://plus.google.com/share?url=' . $url . '" class="icon-social google"><i class="ion ion-social-googleplus"></i></a>';
                break;
            case 'pinterest':
                echo '<a href="' . $url . '" class="item-social pinterest"><i class="ion ion-social-pinterest"></i></a>';
                break;
            default:
                break;
        }
    }
}

if ( ! function_exists( 'art_get_element_template' ) ) {
    function art_get_element_template( $element_name, $args = array(), $template_name = 'default' ) {
        if ( is_array( $args ) && isset( $args ) ) {
            extract( $args );
        }

        if ( false === strpos( $template_name, '.php' ) ) {
            $template_name .= '.php';
        }

        $parent_path = ART_ADDONS_PATH . 'templates/' . $element_name . '/' . $template_name;
        $child_path  = get_stylesheet_directory() . '/superv-addons/' . $element_name . '/' . $template_name;

        if ( file_exists( $child_path ) ) {
            $template_path = $child_path;
        } elseif ( file_exists( $parent_path ) ) {
            $template_path = $parent_path;
        } else {
            _doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_name ), '1.0.0' );

            return;
        }

        require $template_path;
    }
}

/**
 * Visual composer shortcodes
 */
if ( art_plugin_active( 'js_composer/js_composer.php' ) ) {
    require ART_ADDONS_PATH . '/builders/vc-shortcodes/vc_shortcodes.php';
}

/**
 * Elementor widget
 */
if ( art_plugin_active( 'elementor/elementor.php' ) ) {
    require ART_ADDONS_PATH . '/builders/elementor-widget/elementor-widget.php';
}

/**
 * Widgets
 */
require ART_ADDONS_PATH . '/builders/widgets/init.php';

/**
 * Add Import demo functions
 */
require_once ( ART_ADDONS_PATH . 'inc/class_art_file_helper.php' );
require_once ( ART_ADDONS_PATH . 'inc/import-demo.php' );

/**
 * Add new Post type functions
 */
require_once ( ART_ADDONS_PATH . 'inc/post-type.php' );

/**
 * Add library Tax meta
 */
require_once(ART_ADDONS_PATH . 'inc/libs/Tax-meta-class/Tax-meta-class.php');
require_once ( ART_ADDONS_PATH . 'inc/tax-meta.php' );

/**
 * Add func kirki
 */
require_once ( ART_ADDONS_PATH . 'inc/libs/scssphp/scss.inc.php' );
require_once ( ART_ADDONS_PATH . 'inc/libs/kirki/init.php' );
require_once ( ART_ADDONS_PATH . 'inc/libs/kirki/class-kirki-installer-section.php' );
require_once ( ART_ADDONS_PATH . 'inc/libs/kirki/kirki-functions.php' );
?>